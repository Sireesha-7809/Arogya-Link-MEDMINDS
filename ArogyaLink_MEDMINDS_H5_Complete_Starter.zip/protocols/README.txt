ADD OFFICIAL ORGANISER PROTOCOLS HERE

Copy the official simplified public-health protocol documents into this folder as .txt or .md files.
Keep section numbers and headings intact. The assistant only returns a matching local section and its filename/heading.
Do not use invented sample medical content. Until official files are added, the assistant must say no matching protocol is available.
